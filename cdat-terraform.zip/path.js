const paths = require('path');

let directory = paths.join(__dirname)

module.exports = { directory }