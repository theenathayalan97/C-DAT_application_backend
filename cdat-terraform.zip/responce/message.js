let login = "login";
let vpc = "vpc created";
let subnet = "subnet created";
let route_table = "route table created";
let internet_gateway = "internet gateway created";
let nat_gateway = "nat gateway created";
let security_group = "security group created";
let ec2Instance = "ec2 instance created";
let getVpc = "get vpc";
let getSubnet = "get subnet";
let getOs = "get os";
let getSecurityGroup = "get security group";
let s3Bucket = "s3 bucket created";
let accountDestroy = "account destroyed";
let serviceDestroy = "service destroyed";
let create_queue = "queue created";
let snsCreate = "sns Created "
let codePush = "code push"
let codePull = "Code pull"
let rosaCreate = "Rosa create"
let createLoadBalancer = "load balancer created"
let architecture = "architecture created"
let mailSend ="Mail Sent"
let dockerInstance = "Docker instance create"

module.exports ={ login, vpc, subnet, route_table, internet_gateway, 
    nat_gateway, security_group, ec2Instance, getVpc, getSubnet, getOs, getSecurityGroup, s3Bucket
  , accountDestroy, serviceDestroy, create_queue, snsCreate, codePush, codePull, rosaCreate, 
  createLoadBalancer, architecture, mailSend, dockerInstance }